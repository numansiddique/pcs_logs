Log files from memcached containers can be found under
/var/log/containers/memcached.
