Log files from horizon containers can be found under
/var/log/containers/horizon and /var/log/containers/httpd/horizon.
