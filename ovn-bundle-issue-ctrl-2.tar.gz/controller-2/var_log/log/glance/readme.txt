Log files from glance containers can be found under
/var/log/containers/glance.
