Log files from neutron containers can be found under
/var/log/containers/neutron and /var/log/containers/httpd/neutron-api.
