Log files from nova containers can be found under
/var/log/containers/nova and /var/log/containers/httpd/nova-*.
