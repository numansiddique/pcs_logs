Log files from openvswitch containers can be found under
/var/log/containers/openvswitch.
