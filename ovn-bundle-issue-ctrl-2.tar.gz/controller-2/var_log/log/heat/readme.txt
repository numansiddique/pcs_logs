Log files from heat containers can be found under
/var/log/containers/heat and /var/log/containers/httpd/heat-api*.
