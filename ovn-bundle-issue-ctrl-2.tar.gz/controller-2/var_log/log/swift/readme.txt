Log files from swift containers can be found under
/var/log/containers/swift and /var/log/containers/httpd/swift-*.
