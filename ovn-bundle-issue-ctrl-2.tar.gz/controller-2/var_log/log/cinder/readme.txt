Log files from cinder containers can be found under
/var/log/containers/cinder and /var/log/containers/httpd/cinder-api.
