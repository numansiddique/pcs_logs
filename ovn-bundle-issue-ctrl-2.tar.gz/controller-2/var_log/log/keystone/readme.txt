Log files from keystone containers can be found under
/var/log/containers/keystone and /var/log/containers/httpd/keystone.
